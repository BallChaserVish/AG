# CalculatorApp-with-angular-materials
A simple Calculator App which has some features from angular materials.
